﻿namespace KingSurvival.Common
{
    using System;

    public interface IEngine
    {
        void Run();
    }
}
